function visitWebsite(url) {
    window.open(url, '_blank');
  }